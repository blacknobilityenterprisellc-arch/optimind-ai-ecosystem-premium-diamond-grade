// Premium Context Engineering Protocol
// Implements structured prompts with GLM-4.5, OpenRouter, and MCP integration

import { mcpService, MCPAgentConfig } from './mcp-service';
import { agenticWorkflowEngine, AgenticTask } from './agentic-workflow-engine';

export interface ContextPromptTemplate {
  id: string;
  name: string;
  description: string;
  domain: 'healthcare' | 'legal' | 'education' | 'customer-service' | 'general';
  version: string;
  structure: PromptStructure;
  validationRules: ValidationRule[];
  outputFormat: OutputFormat;
  compliance: ComplianceRequirements;
}

export interface PromptStructure {
  sections: PromptSection[];
  requiredSections: string[];
  optionalSections: string[];
  order: string[];
  dependencies: { [key: string]: string[] };
}

export interface PromptSection {
  id: string;
  name: string;
  description: string;
  type: 'directive' | 'profile' | 'state' | 'input' | 'output' | 'safeguard' | 'context';
  required: boolean;
  template: string;
  validation: SectionValidation;
  variables: PromptVariable[];
}

export interface PromptVariable {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  description: string;
  required: boolean;
  defaultValue?: any;
  validation?: VariableValidation;
}

export interface VariableValidation {
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  constraints?: any;
  pattern?: string;
  min?: number;
  max?: number;
  enum?: any[];
}

export interface SectionValidation {
  required: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  customValidation?: string;
}

export interface ValidationRule {
  id: string;
  name: string;
  description: string;
  type: 'syntax' | 'semantic' | 'compliance' | 'security';
  severity: 'error' | 'warning' | 'info';
  condition: string;
  message: string;
}

export interface OutputFormat {
  type: 'json' | 'xml' | 'text' | 'markdown' | 'custom';
  schema?: any;
  template?: string;
  validation: OutputValidation;
}

export interface OutputValidation {
  strict: boolean;
  requiredFields: string[];
  optionalFields: string[];
  typeChecking: boolean;
  customValidation?: string;
}

export interface ComplianceRequirements {
  hipaa?: boolean;
  gdpr?: boolean;
  soc2?: boolean;
  custom?: string[];
  dataRetention?: {
    enabled: boolean;
    duration: number; // in days
    encryption: boolean;
  };
  auditTrail?: {
    enabled: boolean;
    level: 'basic' | 'detailed' | 'comprehensive';
  };
}

export interface ContextPrompt {
  id: string;
  templateId: string;
  variables: { [key: string]: any };
  sections: { [key: string]: string };
  metadata: {
    createdAt: Date;
    updatedAt: Date;
    version: string;
    domain: string;
    agentConfig: MCPAgentConfig;
  };
  validation: {
    isValid: boolean;
    errors: ValidationError[];
    warnings: ValidationWarning[];
    score: number;
  };
}

export interface ValidationError {
  section: string;
  field: string;
  message: string;
  severity: 'error' | 'warning' | 'info';
  ruleId: string;
}

export interface ValidationWarning {
  section: string;
  field: string;
  message: string;
  ruleId: string;
}

export interface ContextPromptGenerationRequest {
  templateId: string;
  variables: { [key: string]: any };
  agentConfig: MCPAgentConfig;
  options?: {
    strictValidation?: boolean;
    includeMetadata?: boolean;
    complianceLevel?: 'basic' | 'standard' | 'strict';
  };
}

export interface ContextPromptGenerationResponse {
  success: boolean;
  prompt?: ContextPrompt;
  errors: string[];
  warnings: string[];
  metadata: {
    generationTime: number;
    validationScore: number;
    complianceScore: number;
  };
}

// Premium Context Templates
export const PREMIUM_CONTEXT_TEMPLATES: ContextPromptTemplate[] = [
  {
    id: 'customer-support-summary',
    name: 'Customer Support Summary',
    description: 'Template for generating structured summaries from customer interactions',
    domain: 'customer-service',
    version: '1.0.0',
    structure: {
      sections: [
        {
          id: 'task_directive',
          name: 'Task Directive',
          description: 'Clear instruction for the AI agent',
          type: 'directive',
          required: true,
          template: '[Task_Directive]\n{directive}',
          validation: { required: true, minLength: 10, maxLength: 500 },
          variables: [
            {
              name: 'directive',
              type: 'string',
              description: 'Clear task instruction',
              required: true,
              validation: { type: 'string', minLength: 10, maxLength: 500 }
            }
          ]
        },
        {
          id: 'agent_profile',
          name: 'Agent Profile',
          description: 'Persona and constraints for the AI agent',
          type: 'profile',
          required: true,
          template: '[Agent_Profile]\n{profile}',
          validation: { required: true, minLength: 20, maxLength: 1000 },
          variables: [
            {
              name: 'profile',
              type: 'string',
              description: 'Agent persona and constraints',
              required: true,
              validation: { type: 'string', minLength: 20, maxLength: 1000 }
            }
          ]
        },
        {
          id: 'system_state',
          name: 'System State',
          description: 'Available tools and routing policies',
          type: 'state',
          required: true,
          template: '[System_State]\nMCP tools: {tools}\nRouting: {routing}',
          validation: { required: true },
          variables: [
            {
              name: 'tools',
              type: 'object',
              description: 'Available MCP tools',
              required: true
            },
            {
              name: 'routing',
              type: 'string',
              description: 'Model routing configuration',
              required: true
            }
          ]
        },
        {
          id: 'input_data',
          name: 'Input Data',
          description: 'Raw input data for processing',
          type: 'input',
          required: true,
          template: '[Input_Data]\n{data}',
          validation: { required: true },
          variables: [
            {
              name: 'data',
              type: 'object',
              description: 'Input data',
              required: true
            }
          ]
        },
        {
          id: 'output_format',
          name: 'Output Format',
          description: 'Desired structured output format',
          type: 'output',
          required: true,
          template: '[Output_Format_Spec]\n{format}',
          validation: { required: true },
          variables: [
            {
              name: 'format',
              type: 'string',
              description: 'Output format specification',
              required: true
            }
          ]
        },
        {
          id: 'safeguard_policy',
          name: 'Safeguard Policy',
          description: 'Compliance rules and error prevention',
          type: 'safeguard',
          required: true,
          template: '[Safeguard_Policy]\n{policy}',
          validation: { required: true, minLength: 10 },
          variables: [
            {
              name: 'policy',
              type: 'string',
              description: 'Safeguard policies',
              required: true,
              validation: { type: 'string', minLength: 10 }
            }
          ]
        }
      ],
      requiredSections: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      optionalSections: [],
      order: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      dependencies: {}
    },
    validationRules: [
      {
        id: 'directive-clarity',
        name: 'Directive Clarity Check',
        description: 'Ensure task directive is clear and actionable',
        type: 'semantic',
        severity: 'error',
        condition: 'directive.length >= 10 && directive.length <= 500',
        message: 'Task directive must be between 10 and 500 characters'
      },
      {
        id: 'profile-completeness',
        name: 'Profile Completeness Check',
        description: 'Ensure agent profile is comprehensive',
        type: 'semantic',
        severity: 'warning',
        condition: 'profile.length >= 20',
        message: 'Agent profile should be at least 20 characters long'
      }
    ],
    outputFormat: {
      type: 'json',
      schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          action_items: { type: 'array', items: { type: 'string' } },
          priority: { type: 'string', enum: ['low', 'medium', 'high'] }
        },
        required: ['summary', 'action_items', 'priority']
      },
      validation: {
        strict: true,
        requiredFields: ['summary', 'action_items', 'priority'],
        optionalFields: [],
        typeChecking: true
      }
    },
    compliance: {
      gdpr: true,
      dataRetention: {
        enabled: true,
        duration: 30,
        encryption: true
      },
      auditTrail: {
        enabled: true,
        level: 'detailed'
      }
    }
  },
  {
    id: 'legal-document-analysis',
    name: 'Legal Document Analysis',
    description: 'Template for comprehensive legal document analysis',
    domain: 'legal',
    version: '1.0.0',
    structure: {
      sections: [
        {
          id: 'task_directive',
          name: 'Task Directive',
          description: 'Legal analysis instruction',
          type: 'directive',
          required: true,
          template: '[Task_Directive]\n{directive}',
          validation: { required: true, minLength: 10 },
          variables: [
            {
              name: 'directive',
              type: 'string',
              description: 'Legal analysis task directive',
              required: true,
              validation: { type: 'string', minLength: 10 }
            }
          ]
        },
        {
          id: 'agent_profile',
          name: 'Agent Profile',
          description: 'Legal expert persona',
          type: 'profile',
          required: true,
          template: '[Agent_Profile]\n{profile}',
          validation: { required: true, minLength: 50 },
          variables: [
            {
              name: 'profile',
              type: 'string',
              description: 'Legal expert persona and constraints',
              required: true,
              validation: { type: 'string', minLength: 50 }
            }
          ]
        },
        {
          id: 'system_state',
          name: 'System State',
          description: 'Legal analysis tools and compliance',
          type: 'state',
          required: true,
          template: '[System_State]\nMCP tools: {tools}\nCompliance: {compliance}\nJurisdiction: {jurisdiction}',
          validation: { required: true },
          variables: [
            {
              name: 'tools',
              type: 'object',
              description: 'Legal analysis tools',
              required: true
            },
            {
              name: 'compliance',
              type: 'string',
              description: 'Compliance requirements',
              required: true
            },
            {
              name: 'jurisdiction',
              type: 'string',
              description: 'Legal jurisdiction',
              required: true
            }
          ]
        },
        {
          id: 'input_data',
          name: 'Input Data',
          description: 'Legal document data',
          type: 'input',
          required: true,
          template: '[Input_Data]\nDocument: {document}\nType: {documentType}',
          validation: { required: true },
          variables: [
            {
              name: 'document',
              type: 'string',
              description: 'Legal document text',
              required: true
            },
            {
              name: 'documentType',
              type: 'string',
              description: 'Document type',
              required: true
            }
          ]
        },
        {
          id: 'output_format',
          name: 'Output Format',
          description: 'Legal analysis output structure',
          type: 'output',
          required: true,
          template: '[Output_Format_Spec]\n{format}',
          validation: { required: true },
          variables: [
            {
              name: 'format',
              type: 'string',
              description: 'Output format specification',
              required: true
            }
          ]
        },
        {
          id: 'safeguard_policy',
          name: 'Safeguard Policy',
          description: 'Legal compliance safeguards',
          type: 'safeguard',
          required: true,
          template: '[Safeguard_Policy]\n{policy}',
          validation: { required: true },
          variables: [
            {
              name: 'policy',
              type: 'string',
              description: 'Legal compliance policies',
              required: true
            }
          ]
        }
      ],
      requiredSections: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      optionalSections: [],
      order: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      dependencies: {}
    },
    validationRules: [
      {
        id: 'legal-jurisdiction',
        name: 'Legal Jurisdiction Check',
        description: 'Ensure legal jurisdiction is specified',
        type: 'compliance',
        severity: 'error',
        condition: 'jurisdiction && jurisdiction.length > 0',
        message: 'Legal jurisdiction must be specified'
      },
      {
        id: 'document-confidentiality',
        name: 'Document Confidentiality Check',
        description: 'Ensure document confidentiality is maintained',
        type: 'security',
        severity: 'error',
        condition: 'policy.includes("confidential")',
        message: 'Confidentiality policy must be included'
      }
    ],
    outputFormat: {
      type: 'json',
      schema: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            field_name: { type: 'string' },
            value: { type: 'string' },
            confidence: { type: 'number', minimum: 0, maximum: 1 }
          },
          required: ['field_name', 'value', 'confidence']
        }
      },
      validation: {
        strict: true,
        requiredFields: ['field_name', 'value', 'confidence'],
        optionalFields: [],
        typeChecking: true
      }
    },
    compliance: {
      gdpr: true,
      soc2: true,
      dataRetention: {
        enabled: true,
        duration: 90,
        encryption: true
      },
      auditTrail: {
        enabled: true,
        level: 'comprehensive'
      }
    }
  },
  {
    id: 'medical-data-analysis',
    name: 'Medical Data Analysis',
    description: 'Template for medical data analysis with HIPAA compliance',
    domain: 'healthcare',
    version: '1.0.0',
    structure: {
      sections: [
        {
          id: 'task_directive',
          name: 'Task Directive',
          description: 'Medical analysis instruction',
          type: 'directive',
          required: true,
          template: '[Task_Directive]\n{directive}',
          validation: { required: true, minLength: 10 },
          variables: [
            {
              name: 'directive',
              type: 'string',
              description: 'Medical analysis task directive',
              required: true,
              validation: { type: 'string', minLength: 10 }
            }
          ]
        },
        {
          id: 'agent_profile',
          name: 'Agent Profile',
          description: 'Medical expert persona',
          type: 'profile',
          required: true,
          template: '[Agent_Profile]\n{profile}',
          validation: { required: true, minLength: 50 },
          variables: [
            {
              name: 'profile',
              type: 'string',
              description: 'Medical expert persona and constraints',
              required: true,
              validation: { type: 'string', minLength: 50 }
            }
          ]
        },
        {
          id: 'system_state',
          name: 'System State',
          description: 'Medical analysis tools and HIPAA compliance',
          type: 'state',
          required: true,
          template: '[System_State]\nMCP tools: {tools}\nHIPAA Compliance: {hipaa}\nMedical Standards: {standards}',
          validation: { required: true },
          variables: [
            {
              name: 'tools',
              type: 'object',
              description: 'Medical analysis tools',
              required: true
            },
            {
              name: 'hipaa',
              type: 'string',
              description: 'HIPAA compliance status',
              required: true
            },
            {
              name: 'standards',
              type: 'string',
              description: 'Medical standards',
              required: true
            }
          ]
        },
        {
          id: 'input_data',
          name: 'Input Data',
          description: 'Medical data',
          type: 'input',
          required: true,
          template: '[Input_Data]\nPatient Data: {data}\nData Type: {dataType}\nConsent: {consent}',
          validation: { required: true },
          variables: [
            {
              name: 'data',
              type: 'object',
              description: 'Medical data',
              required: true
            },
            {
              name: 'dataType',
              type: 'string',
              description: 'Data type',
              required: true
            },
            {
              name: 'consent',
              type: 'string',
              description: 'Patient consent information',
              required: true
            }
          ]
        },
        {
          id: 'output_format',
          name: 'Output Format',
          description: 'Medical analysis output structure',
          type: 'output',
          required: true,
          template: '[Output_Format_Spec]\n{format}',
          validation: { required: true },
          variables: [
            {
              name: 'format',
              type: 'string',
              description: 'Output format specification',
              required: true
            }
          ]
        },
        {
          id: 'safeguard_policy',
          name: 'Safeguard Policy',
          description: 'HIPAA and medical safeguards',
          type: 'safeguard',
          required: true,
          template: '[Safeguard_Policy]\n{policy}',
          validation: { required: true },
          variables: [
            {
              name: 'policy',
              type: 'string',
              description: 'HIPAA compliance policies',
              required: true
            }
          ]
        }
      ],
      requiredSections: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      optionalSections: [],
      order: ['task_directive', 'agent_profile', 'system_state', 'input_data', 'output_format', 'safeguard_policy'],
      dependencies: {}
    },
    validationRules: [
      {
        id: 'hipaa-compliance',
        name: 'HIPAA Compliance Check',
        description: 'Ensure HIPAA compliance requirements are met',
        type: 'compliance',
        severity: 'error',
        condition: 'hipaa.includes("compliant") && policy.includes("HIPAA")',
        message: 'HIPAA compliance must be ensured'
      },
      {
        id: 'patient-consent',
        name: 'Patient Consent Check',
        description: 'Ensure patient consent is documented',
        type: 'compliance',
        severity: 'error',
        condition: 'consent && consent.length > 0',
        message: 'Patient consent must be documented'
      }
    ],
    outputFormat: {
      type: 'json',
      schema: {
        type: 'object',
        properties: {
          terminology: { type: 'array', items: { type: 'string' } },
          conditions: { type: 'array', items: { type: 'string' } },
          medications: { type: 'array', items: { type: 'string' } },
          recommendations: { type: 'array', items: { type: 'string' } }
        },
        required: ['terminology', 'conditions', 'medications', 'recommendations']
      },
      validation: {
        strict: true,
        requiredFields: ['terminology', 'conditions', 'medications', 'recommendations'],
        optionalFields: [],
        typeChecking: true
      }
    },
    compliance: {
      hipaa: true,
      gdpr: true,
      dataRetention: {
        enabled: true,
        duration: 365,
        encryption: true
      },
      auditTrail: {
        enabled: true,
        level: 'comprehensive'
      }
    }
  }
];

class PremiumContextEngineeringService {
  private templates: Map<string, ContextPromptTemplate> = new Map();
  private promptHistory: Map<string, ContextPrompt[]> = new Map();
  private validationCache: Map<string, any> = new Map();

  constructor() {
    this.initializeTemplates();
  }

  private initializeTemplates(): void {
    PREMIUM_CONTEXT_TEMPLATES.forEach(template => {
      this.templates.set(template.id, template);
    });
  }

  // Template Management
  getAvailableTemplates(): ContextPromptTemplate[] {
    return Array.from(this.templates.values());
  }

  getTemplate(templateId: string): ContextPromptTemplate | undefined {
    return this.templates.get(templateId);
  }

  registerTemplate(template: ContextPromptTemplate): void {
    this.templates.set(template.id, template);
  }

  // Context Prompt Generation
  async generateContextPrompt(request: ContextPromptGenerationRequest): Promise<ContextPromptGenerationResponse> {
    const startTime = Date.now();
    
    try {
      const template = this.templates.get(request.templateId);
      if (!template) {
        throw new Error(`Template ${request.templateId} not found`);
      }

      // Validate input variables
      const variableValidation = this.validateVariables(template, request.variables);
      if (!variableValidation.isValid) {
        return {
          success: false,
          errors: variableValidation.errors,
          warnings: [],
          metadata: {
            generationTime: Date.now() - startTime,
            validationScore: 0,
            complianceScore: 0
          }
        };
      }

      // Generate prompt sections
      const sections: { [key: string]: string } = {};
      const sectionErrors: string[] = [];
      const sectionWarnings: string[] = [];

      for (const section of template.structure.sections) {
        try {
          const sectionContent = this.generateSection(section, request.variables, request.agentConfig);
          sections[section.id] = sectionContent;
        } catch (error: any) {
          sectionErrors.push(`Section ${section.id}: ${error.message}`);
        }
      }

      if (sectionErrors.length > 0) {
        return {
          success: false,
          errors: sectionErrors,
          warnings: sectionWarnings,
          metadata: {
            generationTime: Date.now() - startTime,
            validationScore: 0,
            complianceScore: 0
          }
        };
      }

      // Validate the complete prompt
      const validation = this.validatePrompt(template, sections, request.variables);
      
      // Create context prompt object
      const contextPrompt: ContextPrompt = {
        id: `prompt-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        templateId: request.templateId,
        variables: request.variables,
        sections,
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: template.version,
          domain: template.domain,
          agentConfig: request.agentConfig
        },
        validation: {
          isValid: validation.isValid,
          errors: validation.errors,
          warnings: validation.warnings,
          score: validation.score
        }
      };

      // Store in history
      this.storePromptHistory(contextPrompt);

      const generationTime = Date.now() - startTime;

      return {
        success: true,
        prompt: contextPrompt,
        errors: validation.errors.map(e => e.message),
        warnings: validation.warnings.map(w => w.message),
        metadata: {
          generationTime,
          validationScore: validation.score,
          complianceScore: this.calculateComplianceScore(template, validation)
        }
      };
    } catch (error: any) {
      return {
        success: false,
        errors: [error.message],
        warnings: [],
        metadata: {
          generationTime: Date.now() - startTime,
          validationScore: 0,
          complianceScore: 0
        }
      };
    }
  }

  private generateSection(section: PromptSection, variables: { [key: string]: any }, agentConfig: MCPAgentConfig): string {
    let content = section.template;

    // Replace variables in template
    for (const variable of section.variables) {
      const value = this.getVariableValue(variable, variables, agentConfig);
      content = content.replace(new RegExp(`{${variable.name}}`, 'g'), value);
    }

    // Validate section content
    this.validateSectionContent(section, content);

    return content;
  }

  private getVariableValue(variable: PromptVariable, variables: { [key: string]: any }, agentConfig: MCPAgentConfig): string {
    let value = variables[variable.name];

    if (value === undefined || value === null) {
      if (variable.defaultValue !== undefined) {
        value = variable.defaultValue;
      } else if (variable.required) {
        throw new Error(`Required variable ${variable.name} is missing`);
      } else {
        value = '';
      }
    }

    // Special handling for complex variables
    switch (variable.name) {
      case 'tools':
        return JSON.stringify(agentConfig.tools.map(toolId => {
          const tool = mcpService.getTool(toolId);
          return tool ? { id: tool.id, name: tool.name, category: tool.category } : null;
        }).filter(Boolean));
      
      case 'routing':
        return `Using OpenRouter with default routing to ${agentConfig.modelPreference}. Use thinking_mode=true for detailed breakdown.`;
      
      case 'compliance':
        return JSON.stringify(agentConfig.compliance);
      
      case 'jurisdiction':
        return variables.jurisdiction || 'US Federal';
      
      case 'hipaa':
        return agentConfig.compliance.hipaa ? 'HIPAA Compliant' : 'Not HIPAA Applicable';
      
      case 'standards':
        return 'HL7, FHIR, DICOM';
      
      case 'consent':
        return variables.consent || 'Patient consent documented';
      
      default:
        return String(value);
    }
  }

  private validateSectionContent(section: PromptSection, content: string): void {
    const validation = section.validation;

    if (validation.required && !content.trim()) {
      throw new Error(`Section ${section.id} is required but empty`);
    }

    if (validation.minLength && content.length < validation.minLength) {
      throw new Error(`Section ${section.id} must be at least ${validation.minLength} characters long`);
    }

    if (validation.maxLength && content.length > validation.maxLength) {
      throw new Error(`Section ${section.id} must not exceed ${validation.maxLength} characters`);
    }

    if (validation.pattern) {
      const regex = new RegExp(validation.pattern);
      if (!regex.test(content)) {
        throw new Error(`Section ${section.id} does not match required pattern`);
      }
    }
  }

  private validateVariables(template: ContextPromptTemplate, variables: { [key: string]: any }): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];
    let isValid = true;

    // Check all required variables are present
    for (const section of template.structure.sections) {
      for (const variable of section.variables) {
        if (variable.required && !(variable.name in variables)) {
          errors.push(`Required variable ${variable.name} is missing`);
          isValid = false;
        }
      }
    }

    // Validate variable types and constraints
    for (const section of template.structure.sections) {
      for (const variable of section.variables) {
        if (variable.name in variables) {
          const value = variables[variable.name];
          const validation = variable.validation;

          if (validation) {
            const typeError = this.validateVariableType(variable.name, value, validation.type);
            if (typeError) {
              errors.push(typeError);
              isValid = false;
            }

            const constraintError = this.validateVariableConstraints(variable.name, value, validation);
            if (constraintError) {
              errors.push(constraintError);
              isValid = false;
            }
          }
        }
      }
    }

    return { isValid, errors };
  }

  private validateVariableType(name: string, value: any, expectedType: string): string | null {
    const actualType = Array.isArray(value) ? 'array' : typeof value;
    
    if (actualType !== expectedType) {
      return `Variable ${name} must be of type ${expectedType}, got ${actualType}`;
    }
    
    return null;
  }

  private validateVariableConstraints(name: string, value: any, validation: VariableValidation): string | null {
    if (validation.min !== undefined && value < validation.min) {
      return `Variable ${name} must be at least ${validation.min}`;
    }
    
    if (validation.max !== undefined && value > validation.max) {
      return `Variable ${name} must not exceed ${validation.max}`;
    }
    
    if (validation.enum && !validation.enum.includes(value)) {
      return `Variable ${name} must be one of: ${validation.enum.join(', ')}`;
    }
    
    if (validation.pattern && typeof value === 'string') {
      const regex = new RegExp(validation.pattern);
      if (!regex.test(value)) {
        return `Variable ${name} does not match required pattern`;
      }
    }
    
    return null;
  }

  private validatePrompt(template: ContextPromptTemplate, sections: { [key: string]: string }, variables: { [key: string]: any }): {
    isValid: boolean;
    errors: ValidationError[];
    warnings: ValidationWarning[];
    score: number;
  } {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];
    let score = 1.0;

    // Validate required sections
    for (const sectionId of template.structure.requiredSections) {
      if (!sections[sectionId] || !sections[sectionId].trim()) {
        errors.push({
          section: sectionId,
          field: 'content',
          message: `Required section ${sectionId} is missing or empty`,
          severity: 'error',
          ruleId: 'required-section'
        });
        score -= 0.2;
      }
    }

    // Apply validation rules
    for (const rule of template.validationRules) {
      try {
        const result = this.evaluateValidationRule(rule, sections, variables);
        if (!result.passed) {
          const validationError = {
            section: result.section || 'general',
            field: result.field || 'validation',
            message: rule.message,
            severity: rule.severity,
            ruleId: rule.id
          };

          if (rule.severity === 'error') {
            errors.push(validationError);
            score -= 0.1;
          } else {
            warnings.push(validationError as ValidationWarning);
            score -= 0.05;
          }
        }
      } catch (error: any) {
        errors.push({
          section: 'validation',
          field: 'rule-evaluation',
          message: `Rule ${rule.id} evaluation failed: ${error.message}`,
          severity: 'error',
          ruleId: rule.id
        });
        score -= 0.05;
      }
    }

    // Validate output format compatibility
    const formatValidation = this.validateOutputFormat(template.outputFormat, sections.output_format);
    if (!formatValidation.isValid) {
      errors.push(...formatValidation.errors);
      score -= 0.15;
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      score: Math.max(0, Math.min(1, score))
    };
  }

  private evaluateValidationRule(rule: ValidationRule, sections: { [key: string]: string }, variables: { [key: string]: any }): {
    passed: boolean;
    section?: string;
    field?: string;
  } {
    // Create evaluation context
    const context = {
      ...sections,
      ...variables,
      directive: sections.task_directive,
      profile: sections.agent_profile,
      tools: sections.system_state,
      data: sections.input_data,
      format: sections.output_format,
      policy: sections.safeguard_policy
    };

    // Simple rule evaluation (in production, use a proper expression evaluator)
    try {
      // Extract variable names from condition
      const variableMatches = rule.condition.match(/[a-zA-Z_][a-zA-Z0-9_]*/g) || [];
      let condition = rule.condition;

      // Replace variables with actual values
      for (const variable of variableMatches) {
        const value = context[variable];
        if (value !== undefined) {
          if (typeof value === 'string') {
            condition = condition.replace(new RegExp(`\\b${variable}\\b`, 'g'), `"${value}"`);
          } else {
            condition = condition.replace(new RegExp(`\\b${variable}\\b`, 'g'), String(value));
          }
        }
      }

      // Evaluate condition (simplified - in production, use proper expression evaluation)
      const passed = this.evaluateCondition(condition);
      
      return {
        passed,
        section: 'general',
        field: 'validation'
      };
    } catch (error) {
      return {
        passed: false,
        section: 'validation',
        field: 'rule-evaluation'
      };
    }
  }

  private evaluateCondition(condition: string): boolean {
    // Simplified condition evaluation (in production, use a proper expression evaluator)
    try {
      // Handle simple comparisons
      if (condition.includes('>=') || condition.includes('<=') || condition.includes('>') || condition.includes('<')) {
        const parts = condition.split(/(>=|<=|>|<)/);
        if (parts.length === 3) {
          const left = this.parseValue(parts[0].trim());
          const operator = parts[1].trim();
          const right = this.parseValue(parts[2].trim());

          switch (operator) {
            case '>=': return left >= right;
            case '<=': return left <= right;
            case '>': return left > right;
            case '<': return left < right;
            default: return false;
          }
        }
      }

      // Handle includes/contains
      if (condition.includes('includes')) {
        const parts = condition.split('.includes(');
        if (parts.length === 2) {
          const arrayName = parts[0].trim();
          const value = parts[1].replace(')', '').replace(/"/g, '').trim();
          // This is simplified - in production, properly parse the array
          return condition.includes(value);
        }
      }

      // Handle length checks
      if (condition.includes('length')) {
        const lengthMatch = condition.match(/(\w+)\.length\s*(>=|<=|>|<)\s*(\d+)/);
        if (lengthMatch) {
          const variable = lengthMatch[1];
          const operator = lengthMatch[2];
          const length = parseInt(lengthMatch[3]);
          // This is simplified - in production, properly get the variable length
          return true; // Placeholder
        }
      }

      return true; // Default to true for complex conditions
    } catch (error) {
      return false;
    }
  }

  private parseValue(value: string): any {
    // Remove quotes for strings
    if (value.startsWith('"') && value.endsWith('"')) {
      return value.slice(1, -1);
    }
    
    // Parse numbers
    if (/^\d+$/.test(value)) {
      return parseInt(value, 10);
    }
    
    if (/^\d+\.\d+$/.test(value)) {
      return parseFloat(value);
    }
    
    // Parse booleans
    if (value === 'true') return true;
    if (value === 'false') return false;
    
    return value;
  }

  private validateOutputFormat(format: OutputFormat, outputSpec: string): {
    isValid: boolean;
    errors: ValidationError[];
  } {
    const errors: ValidationError[] = [];

    if (!outputSpec || !outputSpec.trim()) {
      errors.push({
        section: 'output_format',
        field: 'content',
        message: 'Output format specification is required',
        severity: 'error',
        ruleId: 'output-format-required'
      });
    }

    if (format.validation.strict && format.schema) {
      try {
        // Validate that output spec matches schema requirements
        const schemaFields = Object.keys(format.schema.properties || {});
        const requiredFields = format.validation.requiredFields || [];
        
        for (const field of requiredFields) {
          if (!schemaFields.includes(field)) {
            errors.push({
              section: 'output_format',
              field: 'schema',
              message: `Required field ${field} not found in schema`,
              severity: 'error',
              ruleId: 'schema-field-missing'
            });
          }
        }
      } catch (error: any) {
        errors.push({
          section: 'output_format',
          field: 'schema',
          message: `Schema validation failed: ${error.message}`,
          severity: 'error',
          ruleId: 'schema-validation'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private calculateComplianceScore(template: ContextPromptTemplate, validation: any): number {
    let score = 1.0;

    // Check compliance requirements
    if (template.compliance.hipaa) {
      score += 0.1;
    }
    if (template.compliance.gdpr) {
      score += 0.1;
    }
    if (template.compliance.soc2) {
      score += 0.1;
    }

    // Check audit trail level
    if (template.compliance.auditTrail) {
      const auditLevels = { 'basic': 0.05, 'detailed': 0.1, 'comprehensive': 0.15 };
      score += auditLevels[template.compliance.auditTrail.level] || 0;
    }

    // Check data retention
    if (template.compliance.dataRetention?.enabled) {
      score += 0.05;
    }

    // Adjust based on validation errors
    const complianceErrors = validation.errors.filter((e: ValidationError) => e.ruleId.includes('compliance'));
    score -= complianceErrors.length * 0.1;

    return Math.max(0, Math.min(1, score));
  }

  private storePromptHistory(prompt: ContextPrompt): void {
    const date = new Date().toDateString();
    if (!this.promptHistory.has(date)) {
      this.promptHistory.set(date, []);
    }
    this.promptHistory.get(date)!.push(prompt);
  }

  // History and Analytics
  getPromptHistory(date?: string): ContextPrompt[] {
    if (date) {
      return this.promptHistory.get(date) || [];
    }
    
    const allHistory: ContextPrompt[] = [];
    for (const prompts of this.promptHistory.values()) {
      allHistory.push(...prompts);
    }
    return allHistory;
  }

  getPromptAnalytics(): any {
    const totalPrompts = Array.from(this.promptHistory.values()).flat().length;
    const templateUsage = new Map<string, number>();
    const domainUsage = new Map<string, number>();
    const averageValidationScore = 0;
    const complianceScores = [];

    for (const prompts of this.promptHistory.values()) {
      for (const prompt of prompts) {
        // Template usage
        templateUsage.set(
          prompt.templateId,
          (templateUsage.get(prompt.templateId) || 0) + 1
        );

        // Domain usage
        domainUsage.set(
          prompt.metadata.domain,
          (domainUsage.get(prompt.metadata.domain) || 0) + 1
        );

        // Validation scores
        averageValidationScore += prompt.validation.score;
        complianceScores.push(this.calculateComplianceScore(
          this.templates.get(prompt.templateId)!,
          prompt.validation
        ));
      }
    }

    return {
      totalPrompts,
      templateUsage: Object.fromEntries(templateUsage),
      domainUsage: Object.fromEntries(domainUsage),
      averageValidationScore: totalPrompts > 0 ? averageValidationScore / totalPrompts : 0,
      averageComplianceScore: complianceScores.length > 0 ? 
        complianceScores.reduce((sum, score) => sum + score, 0) / complianceScores.length : 0
    };
  }

  // Utility Methods
  exportPrompt(prompt: ContextPrompt, format: 'json' | 'text' = 'json'): string {
    if (format === 'json') {
      return JSON.stringify(prompt, null, 2);
    }

    // Text format
    let text = `Context Prompt: ${prompt.id}\n`;
    text += `Template: ${prompt.templateId}\n`;
    text += `Domain: ${prompt.metadata.domain}\n`;
    text += `Generated: ${prompt.metadata.createdAt.toISOString()}\n\n`;

    for (const [sectionId, content] of Object.entries(prompt.sections)) {
      text += `${sectionId.toUpperCase()}:\n${content}\n\n`;
    }

    return text;
  }

  importPrompt(promptData: string): ContextPrompt | null {
    try {
      const prompt = JSON.parse(promptData) as ContextPrompt;
      
      // Validate prompt structure
      if (!prompt.id || !prompt.templateId || !prompt.sections) {
        throw new Error('Invalid prompt structure');
      }

      // Verify template exists
      if (!this.templates.has(prompt.templateId)) {
        throw new Error(`Template ${prompt.templateId} not found`);
      }

      return prompt;
    } catch (error: any) {
      console.error('Failed to import prompt:', error);
      return null;
    }
  }
}

// Export singleton instance
export const premiumContextEngineeringService = new PremiumContextEngineeringService();